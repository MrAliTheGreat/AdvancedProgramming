#include "file-system.hh"

#include <exception>

int main() {
  try {
    FileSystem file_system;
    file_system.add_file("file2");
    file_system.add_file("file1");
    file_system.add_folder("folder1");
    file_system.add_folder("folder2");

    file_system.change_directory("folder1");
    file_system.add_folder("folder1");
    file_system.add_file("file1");
    file_system.add_file("file2");
    file_system.add_file("file3");

    file_system.change_directory("..");
    file_system.sort_by_creation_time();
    file_system.show_tree();
  }

  catch (std::exception *ex) {
    std::cout << ex->what() << std::endl;
  }
}