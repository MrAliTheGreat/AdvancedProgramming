#ifndef _FILE_SYSTEM_FILE_SYSTEM_HH_
#define _FILE_SYSTEM_FILE_SYSTEM_HH_

#include <cstdint>
#include <string>

class FileSystem {
public:
  FileSystem();
  ~FileSystem();

  void add_folder(const std::string name);
  void add_file(const std::string name);
  void change_directory(const std::string path);
  void sort_by_name();
  void sort_by_creation_time();
  void show_tree();
};

#endif
